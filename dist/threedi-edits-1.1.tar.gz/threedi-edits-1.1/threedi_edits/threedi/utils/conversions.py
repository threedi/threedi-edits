# -*- coding: utf-8 -*-
"""
Created on Fri May 27 16:19:34 2022

@author: chris.kerklaan
"""

METER_TO_DEGREE = 0.00001
