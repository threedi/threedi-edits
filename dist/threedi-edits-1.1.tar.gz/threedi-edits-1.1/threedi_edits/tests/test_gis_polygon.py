# -*- coding: utf-8 -*-
"""
Created on Wed Sep 28 13:14:13 2022

@author: chris.kerklaan
"""

# TODO make this
# # First-party imports
# import pathlib

# # Local imports
# from threedi_edits.gis.polygon import Polygon
# from threedi_edits import Vector

# # Globals
# DATA = pathlib.Path(__file__).parent / "data" / "gis_vector.gpkg"
# polygon = Vector(DATA, layer_name="bgt_panden_fixed")[0].geometry.ogr

# def test_centerline():
#     poly = Polygon(polygon)
#     centerline = poly.centerline()
#     empty = Vector.from_scratch("", 3, 28992)
#     empty.add(geometry=centerline)
