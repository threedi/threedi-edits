threedi-edits
==========================================

Introduction

# threedi-edits
An experimental pythonic 3Di schematisation api. Using this api, we can access, alter en write a 3Di database within python. Within the package gis tools are provided as well.  
Currently version '0209' of the schematisation is supported.

# threedi-raster-edits
This package is the continuation of threedi-raster-edits (v0.27) 

Usage
------------
TODO
