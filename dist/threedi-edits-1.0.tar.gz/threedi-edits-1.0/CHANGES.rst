Changelog of threedi-edits
===================================================

1.0 (2022-11-15)
----------------

- Evolution from threedi-raster-edits (v0.27)