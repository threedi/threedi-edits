# -*- coding: utf-8 -*-
"""
Created on Fri Apr 26 14:39:17 2019

@author: chris.kerklaan

These are essentially deprecated. However we still need to find a way to make
this easily available from a single shapely object.

"""
from .point import Point, MultiPoint  # noqa
from .linestring import LineString, MultiLineString  # noqa
from .polygon import Polygon, MultiPolygon  # noqa
