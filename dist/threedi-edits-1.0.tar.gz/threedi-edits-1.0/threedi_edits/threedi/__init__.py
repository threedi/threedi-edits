# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 13:52:55 2019

@author: chris.kerklaan
"""
from threedi_edits.utils.project import Files
from threedi_edits.utils.project import Modules

files = Files(__file__)
modules = Modules(__name__)

# pyflakes
files
modules
