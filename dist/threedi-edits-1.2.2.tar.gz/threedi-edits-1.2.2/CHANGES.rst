Changelog of threedi-edits
===================================================

1.2.2 (2022-11-29)
---------------------------------------------------

- Decoding fix.

1.2.1 (2022-11-29)
---------------------------------------------------

- Versioning support for schema 0210.
- FID column fix.
- Updated sideview example.

1.0 (2022-11-15)
---------------------------------------------------

- Evolution from threedi-raster-edits (v0.27)